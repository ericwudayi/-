var fs = require("fs");
fs.mkdir("mydir",function(err){
    console.log(err)
})